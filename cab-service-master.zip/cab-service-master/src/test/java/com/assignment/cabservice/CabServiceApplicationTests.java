package com.assignment.cabservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
