package com.assignment.cabservice.controller;

import org.springframework.stereotype.Controller;

@Controller
public class UserController {

}
